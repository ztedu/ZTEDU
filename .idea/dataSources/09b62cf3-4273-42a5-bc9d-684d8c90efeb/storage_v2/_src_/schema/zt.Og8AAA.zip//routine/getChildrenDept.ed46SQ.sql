create
  definer = root@localhost function getChildrenDept(deptid int) returns varchar(4000)
BEGIN
DECLARE oTemp VARCHAR(4000);
DECLARE oTempChild VARCHAR(4000);

SET oTemp = '';
SET oTempChild = CAST(deptid AS CHAR);

WHILE oTempChild IS NOT NULL
DO
SET oTemp = CONCAT(oTemp,',',oTempChild);
SELECT GROUP_CONCAT(id) INTO oTempChild FROM comm_sys_dept WHERE FIND_IN_SET(pid,oTempChild) > 0;
END WHILE;
RETURN oTemp;
END;

